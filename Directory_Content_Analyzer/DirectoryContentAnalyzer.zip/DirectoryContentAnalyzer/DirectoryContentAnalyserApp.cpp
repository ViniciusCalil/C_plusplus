/***************************************************************
 * Name:      DirectoryContentAnalyserApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Vinicius Calil ()
 * Created:   2019-02-07
 * Copyright: Vinicius Calil ()
 * License:
 **************************************************************/

#include "DirectoryContentAnalyserApp.h"

//(*AppHeaders
#include "DirectoryContentAnalyserMain.h"
#include <wx/image.h>
//*)


IMPLEMENT_APP(DirectoryContentAnalyserApp);

bool DirectoryContentAnalyserApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	DirectoryContentAnalyserFrame* Frame = new DirectoryContentAnalyserFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
