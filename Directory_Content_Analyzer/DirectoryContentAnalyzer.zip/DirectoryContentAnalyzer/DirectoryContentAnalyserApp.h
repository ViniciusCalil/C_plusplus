/***************************************************************
 * Name:      DirectoryContentAnalyserApp.h
 * Purpose:   Defines Application Class
 * Author:    Vinicius Calil ()
 * Created:   2019-02-07
 * Copyright: Vinicius Calil ()
 * License:
 **************************************************************/

#ifndef DIRECTORYCONTENTANALYSERAPP_H
#define DIRECTORYCONTENTANALYSERAPP_H

#include <wx/app.h>

class DirectoryContentAnalyserApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // DIRECTORYCONTENTANALYSERAPP_H
