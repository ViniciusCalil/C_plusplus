/***************************************************************
 * Name:      DirectoryContentAnalyserMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Vinicius Calil ()
 * Created:   2019-02-07
 * Copyright: Vinicius Calil ()
 * License:
 **************************************************************/


 /*

 IT WAS NEEDED TO INSERT LINK REFERENCES TO THE FOLLOWING STATIC LIBRARIES:
     *) <MinGW_Installation_Directory>\lib\liboleacc.a
     *) <MinGW_Installation_Directory>\lib\libuxtheme.a
     *) <wxWidgets_Installation_Directory>\lib\gcc_lib\libwxjpeg.a
     *) <wxWidgets_Installation_Directory>\lib\gcc_lib\libwxtiff.a
     *) <wxWidgets_Installation_Directory>\lib\gcc_lib\libwxpng.a

 */


#include "DirectoryContentAnalyserMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(DirectoryContentAnalyserFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

#include <wx/dirdlg.h>
#include "Tree.h"


//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format) {
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }
    wxbuild << wxString("\n\nEste aplicativo tem dois objetivos. O primeiro objetivo � criar uma ");
    wxbuild << wxString("lista, que pode ser exportada para um arquivo TXT, contendo todos os nomes ");
    wxbuild << wxString("dos arquivos e subdiret�rios presentes no diret�rio selecionado no campo ");
    wxbuild << wxString("\"Base Directory\" e, se desejado, incluir at� o conte�do dos subdiret�rios.");
    wxbuild << wxString("\n\nO segundo objetivo � criar uma lista, que tamb�m pode ser exportada ");
    wxbuild << wxString("para um arquivo TXT, com os resultados da compara��o do conte�do de dois ");
    wxbuild << wxString("diret�rios. Nesta compara��o, al�m da lista com o nome de cada arquivo e ");
    wxbuild << wxString("subdiret�rio presentes nos dois diret�rios em compara��o, o conte�do de cada ");
    wxbuild << wxString("arquivo presente em um diret�rio (ou subdiret�rio) � comparado com ");
    wxbuild << wxString("o conte�do do arquivo de mesmo nome no respectivo diret�rio (ou ");
    wxbuild << wxString("subdiret�rio) comparado. Esta lista pode se subdividir com a classifica��o ");
    wxbuild << wxString("de: arquivos cujo nome est� presente nos dois diret�rios (ou respectivos ");
    wxbuild << wxString("subdiret�rios) e possuem o mesmo conte�do; arquivos cujo nome est� presente ");
    wxbuild << wxString("nos dois diret�rios (ou respectivos subdiret�rios), mas N�O possuem o mesmo ");
    wxbuild << wxString("conte�do; e, arquivos que est�o presentes em apenas um dos diret�rios (ou ");
    wxbuild << wxString("respectivo subdiret�rio).");
    wxbuild << wxString("\n\nAplicativo desenvolvido por VDSC, em fevereiro de 2019.");
    return wxbuild;
}

//(*IdInit(DirectoryContentAnalyserFrame)
const long DirectoryContentAnalyserFrame::ID_TXCT_BASEDIRECTORY = wxNewId();
const long DirectoryContentAnalyserFrame::ID_BUTTON1 = wxNewId();
const long DirectoryContentAnalyserFrame::ID_RDBT_LISTCONTENTS = wxNewId();
const long DirectoryContentAnalyserFrame::ID_RDBT_COMPAREDIRECTORIES = wxNewId();
const long DirectoryContentAnalyserFrame::ID_TXCT_COMPAREDDIRECTORY = wxNewId();
const long DirectoryContentAnalyserFrame::ID_BT_SEARCHCOMPAREDDIRECTORY = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_SHOWPROPERTIES = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_ANALYZESUBDIR = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_LISTALL = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_LISTEQUALS = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_LISTDIFFERENTS = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_LISTABSENTS = wxNewId();
const long DirectoryContentAnalyserFrame::ID_CKBX_LISTBIGGERS = wxNewId();
const long DirectoryContentAnalyserFrame::ID_BT_ANALYZE = wxNewId();
const long DirectoryContentAnalyserFrame::ID_BT_EXPORT = wxNewId();
const long DirectoryContentAnalyserFrame::ID_TXCT_USEROUTPUT = wxNewId();
const long DirectoryContentAnalyserFrame::ID_PANEL1 = wxNewId();
const long DirectoryContentAnalyserFrame::ID_MENUITEM1 = wxNewId();
const long DirectoryContentAnalyserFrame::idMenuAbout = wxNewId();
const long DirectoryContentAnalyserFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(DirectoryContentAnalyserFrame,wxFrame)
    //(*EventTable(DirectoryContentAnalyserFrame)
    //*)
END_EVENT_TABLE()

DirectoryContentAnalyserFrame::DirectoryContentAnalyserFrame(wxWindow* parent,wxWindowID id) {

    //(*Initialize(DirectoryContentAnalyserFrame)
    wxBoxSizer* BoxSizer10;
    wxBoxSizer* BoxSizer1;
    wxBoxSizer* BoxSizer2;
    wxBoxSizer* BoxSizer3;
    wxBoxSizer* BoxSizer4;
    wxBoxSizer* BoxSizer6;
    wxBoxSizer* BoxSizer7;
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;
    wxStaticBoxSizer* StaticBoxSizer1;
    wxStaticBoxSizer* StaticBoxSizer2;
    wxStaticBoxSizer* StaticBoxSizer3;
    wxStaticBoxSizer* StaticBoxSizer4;
    wxStaticBoxSizer* StaticBoxSizer5;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(852,640));
    Panel1 = new wxPanel(this, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    StaticBoxSizer1 = new wxStaticBoxSizer(wxHORIZONTAL, Panel1, _("Base Directory"));
    TxCt_BaseDirectory = new wxTextCtrl(Panel1, ID_TXCT_BASEDIRECTORY, _("Select the Base Directory to start analyzing its files and subdirectories contents."), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TXCT_BASEDIRECTORY"));
    StaticBoxSizer1->Add(TxCt_BaseDirectory, 1, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer2->Add(StaticBoxSizer1, 1, wxALL|wxEXPAND, 5);
    Bt_SearchBaseDir = new wxButton(Panel1, ID_BUTTON1, _("Search"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    BoxSizer2->Add(Bt_SearchBaseDir, 0, wxALL|wxALIGN_BOTTOM, 5);
    BoxSizer1->Add(BoxSizer2, 0, wxALL|wxEXPAND, 5);
    BoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
    BoxSizer7 = new wxBoxSizer(wxHORIZONTAL);
    RdBt_ListContents = new wxRadioButton(Panel1, ID_RDBT_LISTCONTENTS, _("List Contents and Properties"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_RDBT_LISTCONTENTS"));
    BoxSizer7->Add(RdBt_ListContents, 1, wxLEFT|wxRIGHT, 20);
    RdBt_CompareDirectories = new wxRadioButton(Panel1, ID_RDBT_COMPAREDIRECTORIES, _("Compare Directories Contents"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_RDBT_COMPAREDIRECTORIES"));
    BoxSizer7->Add(RdBt_CompareDirectories, 1, wxLEFT|wxRIGHT, 20);
    BoxSizer3->Add(BoxSizer7, 0, wxALL, 10);
    BoxSizer1->Add(BoxSizer3, 0, wxTOP|wxBOTTOM|wxEXPAND, 2);
    BoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
    StaticBoxSizer2 = new wxStaticBoxSizer(wxHORIZONTAL, Panel1, _("Compared Directory"));
    TxCt_ComparedDirectory = new wxTextCtrl(Panel1, ID_TXCT_COMPAREDDIRECTORY, _("Select a directory to compare its contents to base directory contents."), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TXCT_COMPAREDDIRECTORY"));
    StaticBoxSizer2->Add(TxCt_ComparedDirectory, 1, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer4->Add(StaticBoxSizer2, 1, wxALL|wxEXPAND, 5);
    Bt_SearchComparedDir = new wxButton(Panel1, ID_BT_SEARCHCOMPAREDDIRECTORY, _("Search"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BT_SEARCHCOMPAREDDIRECTORY"));
    BoxSizer4->Add(Bt_SearchComparedDir, 0, wxALL|wxALIGN_BOTTOM, 5);
    BoxSizer1->Add(BoxSizer4, 0, wxALL|wxEXPAND, 5);
    BoxSizer10 = new wxBoxSizer(wxHORIZONTAL);
    StaticBoxSizer3 = new wxStaticBoxSizer(wxVERTICAL, Panel1, _("Contents Options"));
    CkBx_ShowProperties = new wxCheckBox(Panel1, ID_CKBX_SHOWPROPERTIES, _("Show Properties"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_SHOWPROPERTIES"));
    CkBx_ShowProperties->SetValue(false);
    StaticBoxSizer3->Add(CkBx_ShowProperties, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 10);
    CkBx_AnalyzeSubDir = new wxCheckBox(Panel1, ID_CKBX_ANALYZESUBDIR, _("Analyze Subdirectories"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_ANALYZESUBDIR"));
    CkBx_AnalyzeSubDir->SetValue(false);
    StaticBoxSizer3->Add(CkBx_AnalyzeSubDir, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 10);
    BoxSizer10->Add(StaticBoxSizer3, 0, wxALL|wxEXPAND, 5);
    StaticBoxSizer4 = new wxStaticBoxSizer(wxVERTICAL, Panel1, _("Comparison Options"));
    CkBx_ListAll = new wxCheckBox(Panel1, ID_CKBX_LISTALL, _("List All"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_LISTALL"));
    CkBx_ListAll->SetValue(false);
    StaticBoxSizer4->Add(CkBx_ListAll, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 5);
    CkBx_ListEquals = new wxCheckBox(Panel1, ID_CKBX_LISTEQUALS, _("List Equals"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_LISTEQUALS"));
    CkBx_ListEquals->SetValue(false);
    StaticBoxSizer4->Add(CkBx_ListEquals, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 5);
    CkBx_ListDifferents = new wxCheckBox(Panel1, ID_CKBX_LISTDIFFERENTS, _("List Differents"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_LISTDIFFERENTS"));
    CkBx_ListDifferents->SetValue(false);
    CkBx_ListDifferents->SetToolTip(_("Show a list of file names that are in Base Directory and also in Compared Directory and has, at least, different size or different content.\nObservation: is flag \"List Biggers\" is enabled, those file which differ only by size (i.e. all content of smaller file is inside the bigger one) will be shown in a separated list."));
    StaticBoxSizer4->Add(CkBx_ListDifferents, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 5);
    CkBx_ListAbsents = new wxCheckBox(Panel1, ID_CKBX_LISTABSENTS, _("List Absents"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_LISTABSENTS"));
    CkBx_ListAbsents->SetValue(false);
    CkBx_ListAbsents->SetToolTip(_("Show a list of file names that are only in one directory (Base Directory or Compared Directory) and respective subdirectories (when flag \"Analyse Subdirectories\" is enabled)."));
    StaticBoxSizer4->Add(CkBx_ListAbsents, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 5);
    CkBx_ListBiggers = new wxCheckBox(Panel1, ID_CKBX_LISTBIGGERS, _("List Biggers"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CKBX_LISTBIGGERS"));
    CkBx_ListBiggers->SetValue(false);
    CkBx_ListBiggers->SetToolTip(_("Show a list of file names that are in Base Directory and also in Compared Directory. But, although those respective files has different size (and so they are differents), ALL CONTENT OF THE SMALLER FILE IS INSIDE THE BIGGER ONE."));
    StaticBoxSizer4->Add(CkBx_ListBiggers, 1, wxLEFT|wxRIGHT|wxALIGN_LEFT, 5);
    BoxSizer10->Add(StaticBoxSizer4, 0, wxALL|wxEXPAND, 5);
    StaticBoxSizer5 = new wxStaticBoxSizer(wxVERTICAL, Panel1, _("Analysis"));
    Bt_Analyze = new wxButton(Panel1, ID_BT_ANALYZE, _("Start"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BT_ANALYZE"));
    StaticBoxSizer5->Add(Bt_Analyze, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Bt_Export = new wxButton(Panel1, ID_BT_EXPORT, _("Export"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BT_EXPORT"));
    StaticBoxSizer5->Add(Bt_Export, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer10->Add(StaticBoxSizer5, 0, wxALL, 5);
    BoxSizer1->Add(BoxSizer10, 0, wxALL, 0);
    BoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
    TxCt_UserOutPut = new wxTextCtrl(Panel1, ID_TXCT_USEROUTPUT, _("Text"), wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_DONTWRAP, wxDefaultValidator, _T("ID_TXCT_USEROUTPUT"));
    BoxSizer6->Add(TxCt_UserOutPut, 1, wxALL|wxEXPAND, 5);
    BoxSizer1->Add(BoxSizer6, 1, wxALL|wxEXPAND, 5);
    Panel1->SetSizer(BoxSizer1);
    BoxSizer1->Fit(Panel1);
    BoxSizer1->SetSizeHints(Panel1);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, ID_MENUITEM1, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(ID_TXCT_BASEDIRECTORY,wxEVT_COMMAND_TEXT_UPDATED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnTxCt_BaseDirectoryText);
    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnBt_SearchBaseDirClick);
    Connect(ID_RDBT_LISTCONTENTS,wxEVT_COMMAND_RADIOBUTTON_SELECTED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnRdBt_ListContentsSelect);
    Connect(ID_RDBT_COMPAREDIRECTORIES,wxEVT_COMMAND_RADIOBUTTON_SELECTED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnRdBt_CompareDirectoriesSelect);
    Connect(ID_BT_SEARCHCOMPAREDDIRECTORY,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnBt_SearchComparedDirClick);
    Connect(ID_CKBX_LISTALL,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnCkBx_ListAllClick);
    Connect(ID_BT_ANALYZE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnBt_AnalyzeClick);
    Connect(ID_MENUITEM1,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnAbout);
    Connect(wxID_ANY,wxEVT_CLOSE_WINDOW,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnClose);
    //*)


    // My initialization procedure inside Constructor
    BaseDirectoryName = wxEmptyString;
    ComparedDirectoryName  = wxEmptyString;
    Bt_Export->Disable();
    Bt_Analyze->Disable();
    RdBt_ListContents->SetValue(true);

    // Raise event to "RdBt_ListContents".
    // ::wxPostEvent() or wxEvtHandler::ProcessEvent().
    // wxEvtHandler::ProcessEvent(EVT_RADIOBUTTON(ID_RDBT_LISTCONTENTS, (wxCommandEventFunction)&DirectoryContentAnalyserFrame::OnRdBt_ListContentsSelect));
    // Connect(ID_RDBT_LISTCONTENTS,wxEVT_COMMAND_RADIOBUTTON_SELECTED,(wxObjectEventFunction)&DirectoryContentAnalyserFrame::OnRdBt_ListContentsSelect);
    TxCt_ComparedDirectory->Disable();
    Bt_SearchComparedDir->Disable();

}

DirectoryContentAnalyserFrame::~DirectoryContentAnalyserFrame() {
    //(*Destroy(DirectoryContentAnalyserFrame)
    //*)
}

void DirectoryContentAnalyserFrame::OnQuit(wxCommandEvent& event) {
    Close();
}

void DirectoryContentAnalyserFrame::OnAbout(wxCommandEvent& event) {
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void DirectoryContentAnalyserFrame::OnClose(wxCloseEvent& event) {
    Destroy();
}

void DirectoryContentAnalyserFrame::OnBt_SearchBaseDirClick(wxCommandEvent& event) {
    wxDirDialog dlg(NULL, "Choose the Base Directory to be analyzed.", BaseDirectoryName,
                wxDD_DEFAULT_STYLE | wxDD_DIR_MUST_EXIST);
    if (dlg.ShowModal() == wxID_CANCEL)
        return;     // the user changed idea...

    BaseDirectoryName = dlg.GetPath();
    TxCt_BaseDirectory->SetValue(BaseDirectoryName);
    Bt_Analyze->Enable();


    /*  ON OPEN FILE
    wxFileDialog  openFileDialog(this, _("Open Directory"), "", "",
                       "All files (*.*)|*.*", wxFD_OPEN|wxFD_FILE_MUST_EXIST);
    if (openFileDialog.ShowModal() == wxID_CANCEL)
        return;     // the user changed idea...

    // proceed loading the file chosen by the user;
    wxFileInputStream input_stream(openFileDialog.GetPath());
    if (!input_stream.IsOk()) {
        wxLogError("Cannot open file '%s'.", openFileDialog.GetPath());
        return;
    }
    */

    /* On SAVE FILE
        wxFileDialog saveFileDialog(this, _("Save XYZ file"), "", "",
                       "XYZ files (*.xyz)|*.xyz", wxFD_SAVE|wxFD_OVERWRITE_PROMPT);
    if (saveFileDialog.ShowModal() == wxID_CANCEL)
        return;     // the user changed idea...

    // save the current contents in the file;
    wxFileOutputStream output_stream(saveFileDialog.GetPath());
    if (!output_stream.IsOk()) {
        wxLogError("Cannot save current contents in file '%s'.", saveFileDialog.GetPath());
        return;
    }
    */
}

void DirectoryContentAnalyserFrame::OnRdBt_CompareDirectoriesSelect(wxCommandEvent& event) {
    if (RdBt_CompareDirectories->GetValue()) {
        TxCt_ComparedDirectory->Enable();
        Bt_SearchComparedDir->Enable();
    }
}

void DirectoryContentAnalyserFrame::OnRdBt_ListContentsSelect(wxCommandEvent& event) {
    TxCt_ComparedDirectory->Disable();
    Bt_SearchComparedDir->Disable();

}

void DirectoryContentAnalyserFrame::OnBt_SearchComparedDirClick(wxCommandEvent& event) {
    wxDirDialog dlg(NULL, "Choose the Directory to be compared.", ComparedDirectoryName,
                wxDD_DEFAULT_STYLE | wxDD_DIR_MUST_EXIST);
    if (dlg.ShowModal() == wxID_CANCEL)
        return;     // the user changed idea...
    ComparedDirectoryName = dlg.GetPath();

    if (ComparedDirectoryName == BaseDirectoryName) {
        wxMessageBox(wxString("Selected Directory is already defined as your BASE DIRECTORY. You need to choose a different directory to compare contents.!"),
                              "Selected Directory", wxOK | wxCENTRE | wxICON_ERROR);
        TxCt_ComparedDirectory->SetValue("Select a directory to compare its contents to the Base Directory contents.");
        RdBt_CompareDirectories->Disable();
    } else {
        TxCt_ComparedDirectory->SetValue(ComparedDirectoryName);
        RdBt_CompareDirectories->Enable();
    }
}

void DirectoryContentAnalyserFrame::OnCkBx_ListAllClick(wxCommandEvent& event) {
   if (CkBx_ListAll->GetValue()) {
       CkBx_ListEquals->SetValue(true);
       CkBx_ListDifferents->SetValue(true);
       CkBx_ListAbsents->SetValue(true);
       CkBx_ListBiggers->SetValue(true);

       CkBx_ListEquals->Disable();
       CkBx_ListDifferents->Disable();
       CkBx_ListAbsents->Disable();
       CkBx_ListBiggers->Disable();
   } else {
       CkBx_ListEquals->Enable();
       CkBx_ListDifferents->Enable();
       CkBx_ListAbsents->Enable();
       CkBx_ListBiggers->Enable();
   }
}

void DirectoryContentAnalyserFrame::OnBt_AnalyzeClick(wxCommandEvent& event) {
//    wxDateTime dtn = wxDateTime::Now();
//    wxDateTime::Tm tt = dtn.GetTm();
//    TxCt_UserOutPut->SetValue( tt.year );

//    TxCt_UserOutPut->SetValue( dtn.FormatISODate() );
//    TxCt_UserOutPut->SetValue( dtn.FormatTime() );

    if (TxCt_BaseDirectory->GetValue() != wxEmptyString) {
        BaseDirectoryName = TxCt_BaseDirectory->GetValue();
        TreeBDir = Tree();
        TreeBDir.Compose(BaseDirectoryName, CkBx_ShowProperties->IsChecked(),
                         CkBx_AnalyzeSubDir->IsChecked());
        const wxString analyses_result = TreeBDir.Result();   // TreeBDir.Result().c_str()
        TxCt_UserOutPut->SetValue( analyses_result ); // Generating error in debug
    }

    if (RdBt_CompareDirectories->GetValue()) {
        if (TxCt_ComparedDirectory->GetValue() != wxEmptyString) {
            ComparedDirectoryName = TxCt_ComparedDirectory->GetValue();
        }
    } else {

    }


}

void DirectoryContentAnalyserFrame::OnTxCt_BaseDirectoryText(wxCommandEvent& event){
    if (  TxCt_BaseDirectory->GetValue() != wxEmptyString) {
        Bt_Analyze->Enable();
        //BaseDirectoryName = TxCt_BaseDirectory->GetValue();
    }
}


