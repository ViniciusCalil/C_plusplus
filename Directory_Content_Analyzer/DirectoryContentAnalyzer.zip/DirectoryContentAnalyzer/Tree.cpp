/***************************************************************
 * Name:      DirectoryContentAnalyserMain.cpp
 * Purpose:   Code for Tree Structure
 * Author:    Vinicius Calil ()
 * Created:   2019-02-08
 * Copyright: Vinicius Calil ()
 * License:
 **************************************************************/

 /*
 LIST of '#define' for wxWidgets options:
 in file "wx/app.h" :
    wxUSE_GUI
    wxUSE_CMDLINE_PARSER
    wxUSE_EXCEPTIONS
    wxUSE_UNICODE
    wxUSE_THREADS
    __WINDOWS__
    __WXUNIVERSAL__

   //Operative Systems
    __WXMSW__
    __WXMOTIF__
    __WXDFB__
    __WXGTK20__
    __WXGTK__
    __WXX11__
    __WXMAC__
    __WXQT__

*/




#define TREE_CPP
#include "Tree.h"
#define MY_DEBUG_MESSAGE 0

_extern_var_ const int FlSzLen = 15;  // Number of character that the strings with size of files will be displayed.

bool Tree::FileSysObj::prop;  // Flag that indicates if user requested properties to be read and displayed.
bool Tree::FileSysObj::recursive;  // Flag that indicates that the analyses must also verify subdirectories contents recurssively.
ITEMNUMB Tree::FileSysObj::maxitem;  // Flag that set the maximum number of file system objects to be viewed or analysed.

void FileSysObjCounter::Sum(FileSysObjCounter &op1, // 'op1' could be made "const" but would not allow the use of the function this way 'FileSysObjCounter( OP1, OP1, SecondOP);'
                            FileSysObjCounter const &op2) {
    this->regFile = op1.regFile + op2.regFile;
    this->symLink = op1.symLink + op2.symLink;
    this->dir = op1.dir + op2.dir;
    this->others = op1.others + op2.others;
    this->erroFile = op1.erroFile + op2.erroFile;
    this->erroDir = op1.erroDir + op2.erroDir;
};


//void _FileSysObjCounter::Assign(struct _FileSysObjCounter const &op1){
void FileSysObjCounter::Assign(FileSysObjCounter const &op1){
    this->regFile = op1.regFile;
    this->symLink = op1.symLink;
    this->dir = op1.dir;
    this->others = op1.others;
    this->erroFile = op1.erroFile;
    this->erroDir = op1.erroDir;
};


Tree::FileSysObj::FileSysObj(){
    this->name = wxEmptyString;
    this->parent = NULL;
    this->pos = std::list<ITEMNUMB>();

    this->dt_modified = wxDateTime(1,  wxDateTime::Jan, 1, 0, 0, 0);  //wxDateTime();
    this->dt_created  = wxDateTime(this->dt_modified);  //wxDateTime();
    this->dt_accessed = wxDateTime(this->dt_modified);  //wxDateTime();
};


std::list<ITEMNUMB> Tree::FileSysObj::GetPosition(){
    std::list<ITEMNUMB> lst = std::list<ITEMNUMB>(this->pos);
    return lst;
};


wxString Tree::FileSysObj::GetPath(){
    // if the Tree object in which this FileSysObj object is associated has its 'root.name' member
    // set with a relative path (to the Current Working Directory) this 'Tree::FileSysObj::GetPath()'
    // method  will return also a relative path (to the Current Working Directory).
    wxString path = wxEmptyString;
    Tree::FileSysObj* sysobj = this->parent;
    if (sysobj == NULL) { // True if sysobj is a pointer to 'Tree.root' (Tree::SysDir) object.
        path = wxPathOnly(this->name) + wxFILE_SEP_PATH;
    } else {
        while (sysobj != NULL) {
            path = sysobj->name + wxFILE_SEP_PATH + path;
            sysobj = sysobj->parent;
        };
    };
    return path;
}


bool Tree::SysDir::SetSystemObjectTo(const wxString &Fname, const wxString &Fpath) { //(wxString Fullname) {
/*
    // Considering that file system is not changed while this program is running, 'Fname' and
    // 'Fpath' do not need be verified because the root directory (supplied by user) is already
    // checked in 'Tree.SetRoot()' and, after that, all other file system object name is passed by
    // OS file system.
    if (Fname.IsNull() || (Fname == wxEmptyString) || Fpath.IsNull() || (Fpath == wxEmptyString))  {
        wxMessageBox(wxString("Invalid file system object pointer or file system object name!"),
                     wxString("File System Object ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }
*/
    wxString Fullname = Fpath + Fname;
/*
    if (!wxDirExists(Fullname)) {  // Check if 'Fullname' is a valid Directory without verifying if it is accessible or not (due to permissions, share options in case it is already owned by other process).
        return false; // Fname is not a valid Directory name.
    }
*/
    this->childrenDirs = std::list<SysDir*>();
    this->childrenFiles = std::list<SysFile*>();
    wxFileName fln;    // wxFFile ffl;
    fln.DontFollowLink();
    fln =  wxFileName::DirName(Fullname);
/*
    if (!fln.IsOk()){  // This verification is not needed because 'wxDirExists(Fullname)' has verified it before.
        wxMessageBox(wxString("Invalid Directory name!"),
                     wxString("System Object Name ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    };
*/
    if (FileSysObj::prop)
        fln.GetTimes(&this->dt_accessed, &this->dt_modified, &this->dt_created);

    this->name = Fname;
    return true;
};


#ifdef __WXMSW__
/*

Tree::SysFile::SysFile(){
    ads_list = std::list<AltDataStream>();
}


Tree::SysFile::~SysFile(){
    ads_list.clear();
}
*/
#endif // __WXMSW__


Tree::SysDir::SysDir(){
    childrenDirs = std::list<SysDir*>();
    childrenFiles = std::list<SysFile*>();
    localfiles = localsymlink = localdirectories = localothers = 0;
    localerrorsfile = localerrorsdir = 0;
    subdirfiles = subdirsymlink = subdirdirectories = subdirothers = 0;
    subdirerrorsfile = subdirerrorsdir = 0;
}


Tree::SysDir::~SysDir(){
    childrenDirs.clear();
    childrenFiles.clear();
}


bool Tree::SysFile::SetSystemObjectTo(const wxString &Fname, const wxString &Fpath) {   // (wxString Fname) {
    /*
    // Considering that file system is not changed while this program is running, 'Fname' and
    // 'Fpath' do not need be verified because the root directory (supplied by user) is already
    // checked in 'Tree.SetRoot()' and, after that, all other file system object name is passed by
    // OS file system.
    if (Fname.IsNull() || (Fname == wxEmptyString) || Fpath.IsNull() || (Fpath == wxEmptyString))  {
        wxMessageBox(wxString("Invalid file system object pointer or file system object name!"),
                     wxString("File System Object ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }
*/
    wxString Fullname = Fpath + Fname;
/*
    if (!wxDirExists(Fullname)) {  // Check if 'Fullname' is a valid Directory without verifying if it is accessible or not (due to permissions, share options in case it is already owned by other process).
        return false; // Fname is not a valid Directory name.
    }
*/

    if (wxDirExists(Fullname)) {  // Check if 'Fname' is a valid Directory without verifying if it is accessible or not (due to permissions, share options in case it is already owned by other process).
        return false; // Fname is not a valid FILE name.
    } else {
        wxFileName fln(Fullname);    // wxFFile ffl;
        fln.DontFollowLink();
        if ( (fln.IsOk()) && (fln.Exists(wxFILE_EXISTS_ANY)) ){ // Check if the Fname is a valid name and if there exist any File System object with its name.
            if (fln.Exists(wxFILE_EXISTS_SYMLINK)){   // Check if there exist a SYMBOLIC LINK with 'fln' name.
                this->type = Tree::SysFile::symbolicLink;
            } else if (fln.Exists(wxFILE_EXISTS_REGULAR)){   // Check if there exist a REGULAR FILE with 'fln' name.
                this->type = Tree::SysFile::regularFile;
            } else {
                this->type = Tree::SysFile::others;
            }
            if (FileSysObj::prop) {
                this->len = fln.GetSize();  //  If file size could not be read (because e.g. the file is locked by another process) the returned value is wxInvalidSize.
                fln.GetTimes(&this->dt_accessed, &this->dt_modified, &this->dt_created);
            }
            this->name = Fname;

#ifdef __WXMSW__
       // struct AltDataStream {
       //     wxString adsName;  // name of Alternate DATA Stream (ADS) present in NTFS file system.
       //     int_fast64_t sz;   // size of ADS
       // };
       // std::list<AltDataStream> ads_list;
/*            {

            LPCWSTR lpFileName = Fname.c_str();
            LPVOID lpFindStreamData;
            DWORD dwFlags;
            STREAM_INFO_LEVELS InfoLevel;
            HANDLE ads_hnd = FindFirstStreamW(lpFileName, InfoLevel,
                                              lpFindStreamData, dwFlags);
            }
*/

#endif // __WXMSW__

            return true;
        } else {
            return false; // Fname is not a valid name neither there exist a valid System Object (file or directory).
        }
    }
};


bool Tree::SysDir::SetDirChild(Tree::SysDir* child) {
/*
    if ((child == NULL) ||
        (child->name == wxEmptyString )){
        wxMessageBox(wxString("Invalid pointer to child directory system object!"),
                     wxString("System Object Pointer ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }

    if (this->name == wxEmptyString)  // If 'this->name' is not empty , the method 'SetSystemObjectTo' has been called and 'prnt' is a valid Directory.
        return false;
*/

    if (this->GetDirSiblingIndex(child) == -2) { // 'this' is not includded in 'prtn->childrenDirs'.
        child->pos = std::list<ITEMNUMB>(this->pos);  // Item position inside the tree. First sibling ref "0" index.
        child->pos.push_back(this->childrenDirs.size());
        this->childrenDirs.push_back(child);
        child->parent = this;
        return true;
    }
    return false;
};


bool Tree::SysDir::SetFileChild(Tree::SysFile* child) {
/*
    if ((child == NULL) ||
        (child->GetName() == wxEmptyString )){
        wxMessageBox(wxString("Invalid pointer to child file system object!"),
                     wxString("System Object Pointer ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }

    if (this->name == wxEmptyString)  // If 'this->name' is not empty , the method 'SetSystemObjectTo' has been called and 'prnt' is a valid Directory.
        return false;
*/
    if (this->GetFileSiblingIndex(child) == -2) { // 'this' is not includded in 'prtn->childrenDirs'.
        child->pos = std::list<ITEMNUMB>(this->pos);  // Item position inside the tree. First sibling ref "0" index.
        child->pos.push_back(this->childrenFiles.size());
        this->childrenFiles.push_back(child);
        child->parent = this;
        return true;
    }
    return false;
};


ITEMNUMB Tree::SysDir::GetDirSiblingIndex(Tree::SysDir* child) {
    // Return the index (base 0) inside 'this->children' list<FileSys>
    // that points to argument 'child'.
//    if ((child == NULL) || (child->name == wxEmptyString)) return -1; // Error 'child' is not a valid Directory.

    std::list<SysDir*>::iterator it = this->childrenDirs.begin();
    ITEMNUMB index = 0;
    for (; (*it != child) && (it != this->childrenDirs.end()); ++it, ++index);
        // An iterator doesn't necessarily point to an object that is stored in memory somewhere;
        // it just has to do something to come up with a value when you dereference it. This is why
        // sometimes it is needed to get the object by '(*it)' and then, get the object address '&(*it)'.
        // See: https://www.quora.com/What-is-the-difference-between-a-reference-a-pointer-and-an-iterator-Why-is-it-a-good-practice-to-use-special-iterators-instead-of-normal-variables-for-loops
    if (it == this->childrenDirs.end()) {
        return -2;   // 'child' is not a childrem of 'this' FileSys object.
    } else {
        return index;
    }
}


ITEMNUMB Tree::SysDir::GetFileSiblingIndex(Tree::SysFile* child) {
    // Return the index (base 0) inside 'this->children' list<FileSys>
    // that points to argument 'child'.
//    if ((child == NULL) || (child->name == wxEmptyString)) return -1; // Error 'child' is not a valid File.

    std::list<SysFile*>::iterator it = this->childrenFiles.begin();
    ITEMNUMB index = 0;
    for (; (*it != child) && (it != this->childrenFiles.end()); ++it, ++index);
        // An iterator doesn't necessarily point to an object that is stored in memory somewhere;
        // it just has to do something to come up with a value when you dereference it. This is why
        // sometimes it is needed to get the object by '(*it)' and then, get the object address '&(*it)'.
        // See: https://www.quora.com/What-is-the-difference-between-a-reference-a-pointer-and-an-iterator-Why-is-it-a-good-practice-to-use-special-iterators-instead-of-normal-variables-for-loops
    if (it == this->childrenFiles.end()) {
        return -2;   // 'child' is not a childrem of 'this' FileSys object.
    } else {
        return index;
    }
}


bool Tree::SysDir::SetRoot(Tree* tree, const wxString &Fullname) {  // set 'parent' and 'pos'.//ITEMNUMB GetSiblingFileIndex(FileSysObj* child); // A FileSys object may use 'this->parent.GetSiblingIndex(this)' to know its index position inside "this->parent.children" list<FileSys>.
 /*
    if (tree == NULL) { // This is not needed because only an existente 'Tree' object can call its own (private) class member 'SysDir'.
        wxMessageBox(wxString("Invalid pointer to system objects tree!"),
                     wxString("System Object Tree Pointer ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }
*/
    if (Fullname.IsNull())  {
        wxMessageBox(wxString("Invalid ROOT Directory pointer!"),
                     wxString("ROOT Directory Pointer ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    } else if (Fullname == wxEmptyString) {
        wxMessageBox(wxString("Invalid ROOT Directory name!"),
                     wxString("ROOT Directory Name ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }

    // Observation: the macro 'wxFILE_SEP_PATH' resolves to a string which contents is the character
    //              used by the Operative System (Windows, Linux, Mac OS, etc) where this program is
    //              compiled, that is used to separate the directories names inside the same path
    //              of a file system object (directory or file). The macro 'wxPATH_SEP' resolves to
    //              string which content is the separator used by OS when multiple file system objects
    //              are selected simultaneously in 'Open File Dialog'.

    wxString fileName, fileExtension, fileVolume, filePath;
    bool hasExtension = false;
    wxFileName::SplitPath(Fullname, &fileVolume, &filePath, &fileName,  // Fullname, fileVolume, filePath, &fileName,
                            &fileExtension, &hasExtension, wxPATH_NATIVE);
    wxString fileNameExt = fileName;
    if (hasExtension)
        fileNameExt += "." + fileExtension;

    if (fileNameExt == wxEmptyString) {
            wxMessageBox(wxString("Invalid file system object name!"),
                         wxString("System Object Name ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
            return false;
    }

    //wxString rootpath = fileVolume + wxFILE_SEP_PATH + filePath + wxFILE_SEP_PATH;
    wxString rootpath(wxPathOnly(Fullname) + wxFILE_SEP_PATH);  // This is the path in same way user pass it.
    // In 'rootpath' Environment variables name and symbolic link is not resolved, also if
    //it is a relative path (to Current Working Directory) it keeps as relative.
    // See also function 'wxFileNameFromPath(const wxString& FullName);


    wxFileName dirname = wxFileName::DirName(Fullname, wxPATH_NATIVE);
    if (dirname.IsOk()) {
        dirname.Normalize(wxPATH_NORM_ENV_VARS  | wxPATH_NORM_TILDE |
                          wxPATH_NORM_ABSOLUTE  | wxPATH_NORM_LONG | wxPATH_NORM_DOTS,
                          Fullname, wxPATH_NATIVE); // This is the path with all
    // Environment variables name, '~' and '~user' unix ("symbolic dynamic links") and
    // symbolic links resolved. Also, the path is became in the absolute path.
    }

/*
    wxDir dirname = wxDir(Fullname);
    if (dirname.Exists()) {
        tree->path = dirname.GetNameWithSep()
    } else {
        return false;

    }
*/
    tree->path = dirname.GetName() + wxFILE_SEP_PATH;
#if (MY_DEBUG_MESSAGE) >= 1
    wxMessageBox( wxString("Directory '") + fileNameExt +
                  wxString( "' is the root. Its Path is: '") + rootpath +
                  wxString( "' and its ABSOLUTE PATH is: ") + tree->path,
                  wxString("Debubg info"),wxOK|wxCENTRE);
#endif
    if (!tree->root.SetSystemObjectTo(fileNameExt, rootpath)) {
        wxMessageBox(wxString("Invalid Subtree root Directory !"),
                     wxString("SUBTREE ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }
    this->parent = NULL;
    this->name = Fullname;

    return true;
};


FileSysObjCounter Tree::SysDir::Traverse(ITEMNUMB nitem, const wxString& path){
    FileSysObjCounter cntr = {0, 0, 0, 0, 0, 0};
    if (nitem>= FileSysObj::maxitem) {
        // The number of FileSys (files and directories) objects in the 'Tree'
        // object are greatter then 'Tree.itemMax' or 'this->name' is not a directory.
        cntr.erroFile = -1;
        return cntr;
    }

    // Verify if Directory is accessible;
    // The cases '(path.IsNull() || (path == wxEmptyString))' is not checked because 'path' is passed by
    // OS. file system
    wxDir dir(path);      // Check if 'this->name' is a valid accessible Directory trying to open it (to allow enumeration of its files and subdirectories).
    bool diropen = dir.IsOpened();  // Check if 'this->name' Directory is open.
    if (!diropen) { // 'this->name' may be a Directory, but it is not accessible.
            cntr.erroDir = -1;
        return cntr;
    }

     // read all subdirectories, create a SysDir to each one and count them with 'cntr'.
    wxString sysObjName;
    wxString regExpFilter("*.*");
    SysDir* sd;

    // sysObjName = wxFindFirstFile(regExpFilter, wxDIR_DIRS | wxDIR_HIDDEN | wxDIR_NO_FOLLOW);  //Avoided because it is not thread-safe.
    bool newSysObj = dir.GetFirst(&sysObjName, wxEmptyString, wxDIR_DIRS | wxDIR_HIDDEN | wxDIR_NO_FOLLOW);
    while ( newSysObj ) {
        sd = new SysDir();
        if(sd->SetSystemObjectTo(sysObjName, path)){
            if (this->SetDirChild(sd)) {
                ++cntr.dir;
            } else {
                ++cntr.erroDir; // A Directory could not been included in the tree structure.
            }
        } else {
            ++cntr.erroDir; // A Directory could not been included in the tree structure.
        }
        //delete sd;  // This line is not necessary because the "SysDir" object pointed by 'sd' is moved (instead of copied) to 'this->childrenDirs' in line 'this->childrenDirs.push_back(sd)' from 'Tree::SysFile.SetFileChild(SysDir* sd)'.
        if (cntr.dir + nitem >= FileSysObj::maxitem) {
            dir.Close();  // Close 'this->name' Directory.
            cntr.erroFile = -1;
            this->LoadLocalStatistics(cntr);
            return cntr;
        }
        newSysObj = dir.GetNext(&sysObjName);
    }

     // read all File, create a SysFile to each one and count them with 'cntr'.
    // sysObjName = wxFindFirstFile(wxString("./") + regExpFilter, wxDIR_FILES | wxDIR_HIDDEN | wxDIR_NO_FOLLOW);  //Avoided because it is not thread-safe.
    SysFile* sf;
    ITEMNUMB tempcntr = cntr.dir + nitem;
    // newSysObj = dir.GetFirst(&sysObjName, regExpFilter, wxDIR_FILES | wxDIR_HIDDEN | wxDIR_NO_FOLLOW);
    newSysObj = dir.GetFirst(&sysObjName, wxEmptyString, wxDIR_FILES | wxDIR_HIDDEN | wxDIR_NO_FOLLOW);
    while ( newSysObj ) {
        sf = new SysFile();
//        if(sf->SetSystemObjectTo(sysObjName)){
        if(sf->SetSystemObjectTo(sysObjName, path)){
            if (this->SetFileChild(sf)) {
                if (sf->type == SysFile::regularFile) {
                    ++cntr.regFile;
                }else if (sf->type == SysFile::symbolicLink) {
                    ++cntr.symLink;
                } else {  //if(sf->type == SysFile::others) {
                    ++cntr.others;
                }
                ++tempcntr;
            } else {
                ++cntr.erroFile;  // A File could not been included in the tree structure.
            }
        } else {
            ++cntr.erroFile;  // A File could not been included in the tree structure.
        }
        //delete sf; // This line is not necessary because the "SysFile" object pointed by 'sf' is moved (instead of copied) to 'this->childrenFiles' in line 'this->childrenFiles.push_back(sf)' from 'Tree::SysFile.SetFileChild(SysFile* sf)'.
        if (tempcntr >= FileSysObj::maxitem) {
            dir.Close();  // Close 'this->name' Directory.
            cntr.erroFile = -1;
            this->LoadLocalStatistics(cntr);
            return cntr;
        }
        newSysObj = dir.GetNext(&sysObjName);
    }
    dir.Close();  // Close 'this->name' Directory.
    this->LoadLocalStatistics(cntr);
    return cntr;
};


FileSysObjCounter Tree::SysDir::RecursiveTraverse(ITEMNUMB nitem, const wxString& path){
    FileSysObjCounter cntr = {0, 0, 0, 0, 0, 0};
    if (nitem>= FileSysObj::maxitem) {
        // The number of FileSys (files and directories) objects in the 'Tree'
        // object are greatter then 'Tree.itemMax' or 'this->name' is not a directory.
        cntr.erroFile = -1;
        return cntr;
    }

    cntr = this->Traverse(nitem, path);
//    this->LoadLocalStatistics(cntr);
    if (cntr.erroFile == -1) {  // The number of file system object viewed (nitem) has become greater then 'FileSysObj::maxitem'.
        return cntr;
    } else if (cntr.erroDir == -1 ) { // The directory inside 'path' is not accessible.
        cntr.erroDir = 1;
        return cntr;
    }
    FileSysObjCounter subcntr = {0, 0, 0, 0, 0, 0};
    if (cntr.dir>0) { // Verify if 'this' SysDir has any subdirectory.
        nitem += cntr.Viewed();
        if (nitem >= FileSysObj::maxitem)
            return cntr;
        std::list<SysDir*>::iterator it = this->childrenDirs.begin();
        std::list<SysDir*>::iterator itF = this->childrenDirs.end();
        FileSysObjCounter tempcntr = {0, 0, 0, 0, 0, 0};
        for(; it != itF; ++it) {
            tempcntr = (*it)->RecursiveTraverse(nitem, path + (*it)->name + wxFILE_SEP_PATH);
            nitem += tempcntr.Viewed();
            subcntr.Sum(subcntr, tempcntr);
            this->LoadSubdirStatistics(subcntr);
            if (nitem >= FileSysObj::maxitem){
                cntr.Sum(cntr, subcntr);
                return cntr;
            };
        }
    } else if (cntr.dir == 0) {
        return cntr;
    }
    cntr.Sum(cntr, subcntr);
    return cntr;
}


void Tree::SysDir::LoadLocalStatistics(FileSysObjCounter &statistics){
    this->localdirectories = statistics.dir;
    this->localfiles = statistics.regFile;
    this->localsymlink = statistics.symLink;
    this->localothers = statistics.others;
    this->localerrorsdir = statistics.erroDir;
    this->localerrorsfile = statistics.erroFile;
};


void Tree::SysDir::LoadSubdirStatistics(FileSysObjCounter &statistics){
    this->subdirdirectories = statistics.dir;
    this->subdirfiles = statistics.regFile;
    this->subdirsymlink = statistics.symLink;
    this->subdirothers = statistics.others;
    this->subdirerrorsdir = statistics.erroDir;
    this->subdirerrorsfile = statistics.erroFile;
};


wxString Tree::SysDir::ToString(const wxString &path){
    wxString output = "\n============================================================\n\n";
    output << path << this->name <<"\n" ;
    wxString pos = wxString("\tPosition: Base.");
    if (this->pos.size()>0){
        std::list<ITEMNUMB>::iterator it = this->pos.begin();
        std::list<ITEMNUMB>::iterator itf = this->pos.end();
        while (it != itf){
            pos << *it << ".";
            ++it;
        }
    };
    output << pos << "\n";
    if (Tree::FileSysObj::prop) {
        output << "\tTimes:\t\tModification: " // << std::setw(10)
           << this->dt_modified.FormatISOCombined(' ') << ";\tCreation (in MSW): "
           << this->dt_created.FormatISOCombined(' ') <<  ";\tAccess: "
           << this->dt_accessed.FormatISOCombined(' ') << ".\n";
    };

    output << "\tLOCAL CONTENTS:\n\t\t" << "Dir: "
           << wxString::Format(wxT("%5lli"),this->localdirectories) //setw(5) << setprecision(5) << this->localdirectories
           << "; File: " << wxString::Format(wxT("%8lli"),this->localfiles) // << setw(8) << setprecision(8) << this->localfiles
           << "; SymLink: " << wxString::Format(wxT("%4lli"),this->localsymlink) //<< setw(4) << setprecision(4) << this->localsymlink
           << "; others: " << wxString::Format(wxT("%4lli"),this->localothers); // << this->localothers << ";\n";
    output << "\t\tErrors => Dir: " << wxString::Format(wxT("%5lli"),this->localerrorsdir)
           << "; Files, Symlinks and others: "
           << wxString::Format(wxT("%8lli"),this->localerrorsfile) << ";" ;
    if (FileSysObj::recursive) {
        output << "\n\tSUBDIRECTORIES CONTENTS:\n\t\t" << "Dir: "
               << wxString::Format(wxT("%5lli"),this->subdirdirectories) //setw(5) << setprecision(5) << this->localdirectories
               << "; File: " << wxString::Format(wxT("%8lli"),this->subdirfiles) // << setw(8) << setprecision(8) << this->localfiles
               << "; SymLink: " << wxString::Format(wxT("%4lli"),this->subdirsymlink) //<< setw(4) << setprecision(4) << this->localsymlink
               << "; others: " << wxString::Format(wxT("%4lli"),this->subdirothers); // << this->localothers << ";\n";
        output << "\t\tErrors => Dir: " << wxString::Format(wxT("%5lli"),this->subdirerrorsdir)
               << "; Files, Symlinks and others: "
               << wxString::Format(wxT("%8lli"),this->subdirerrorsfile) << ";" ;
    }

    output << "\n------------------------------------------------------------\n";
//    if ((this->childrenDirs != NULL) && (this->childrenDirs.size()>0)) {
    if (this->childrenDirs.size() > 0 ) {
        output << "\tDirectories:\n";
        std::list<SysDir*>::iterator it = this->childrenDirs.begin();
        std::list<SysDir*>::iterator itf = this->childrenDirs.end();
        for(; it!=itf; ++it) {
            output << "\t\t" << (*it)->name << " \n";
        };
    } else {
        output << "\t\t***No directory inside.\n";
    }
    wxString outReg, outSym, outOther, ftimes, fsize;
    outReg = wxEmptyString;
    outSym = wxEmptyString;
    outOther = wxEmptyString;
    ftimes = wxEmptyString;
    fsize = wxEmptyString;

    ITEMNUMB freg, fsym, fother; // Flags to count the number of files, for each type.
    freg = fsym = fother = 0;
//    if ((this->childrenFiles!=NULL) && (this->childrenFiles.size()>0)) {
    if (this->childrenFiles.size() > 0) {
        outReg << "\tRegular Files:\n";
        outSym << "\tSymbolic Links:\n";
        outOther << "\tOther type:\n";

        std::list<SysFile*>::iterator it = this->childrenFiles.begin();
        std::list<SysFile*>::iterator itf = this->childrenFiles.end();
        wxString sizeformat = "%" + wxString::Format("%i",FlSzLen) + "s";  //  If 'FlSzLen'=15, then 'sizeformat'= wxString("%15s").
        for(; it!=itf; ++it) {
            int ftype = (*it)->type;
            if (Tree::FileSysObj::prop) {
                ftimes = "Times: Mo= " +
                        (*it)->dt_modified.FormatISOCombined(' ') + ";  Cr= " +
                        (*it)->dt_created.FormatISOCombined(' ') +  ";  Ac= " +
                        (*it)->dt_accessed.FormatISOCombined(' ');
            };
            if (ftype == Tree::SysFile::regularFile){
                ++freg;
                outReg << "\t\t" << (*it)->name << " \n";
                if (FileSysObj::prop) {
                    fsize = wxString::Format(sizeformat,
                                        wxFileName::GetHumanReadableSize((*it)->len,
                                                                         wxGetTranslation("Empty"),
                                                                         4, wxSIZE_CONV_IEC) );
                    //output << wxString::Format(wxT("%15llu"), (((ULONGLONG)(*it)->len.GetHi())<<32) + (ULONGLONG)(*it)->len.GetLo() ) <<  " <-> " ;
                    //output << "High=" << wxString::Format(wxT("%8lu"), (*it)->len.GetHi() ) <<  " <-> " ;
                    //output << "Low="  << wxString::Format(wxT("%8lu"), (*it)->len.GetLo() ) <<  " <-> " ;
                    //output << wxString::Format(wxT("%15llu"), (wxULongLong_t)(*it)->len.GetValue() ) <<  " <-> " ;
                    fsize << " (" << wxString::Format(sizeformat, //wxT("%15s"),
                                                       (*it)->len.ToString()) <<  " B)  ->  " ;
                    outReg << "\t\t\t" << fsize << ftimes << ".\n";
                }
            } else if (ftype == Tree::SysFile::symbolicLink) {
                ++fsym;
                outSym << "\t\t" << (*it)->name << " \n";
                if (FileSysObj::prop) {outSym << "\t\t\t" << ftimes << ".\n"; };
            } else { // if (ftype == Tree::SysFile::others) {
                ++fother;
                outOther << "\t\t" << (*it)->name << " \n";
                if (FileSysObj::prop) {outOther << "\t\t\t" << ftimes << ".\n"; };
            }

        }
    } else {
        output << "\t\t***No Regular Files inside.\n";
    };
    if (freg > 0) {
        output << "------------------------------------------------------------\n" << outReg;
    };
    if (fsym > 0) {
        output << "------------------------------------------------------------\n" << outSym;
    };
    if (fother > 0) {
        output << "------------------------------------------------------------\n" << outOther;
    };
//    output << "\n";

    return output;
};


wxString Tree::SysDir::TreeToString(const wxString &path) {

#if (MY_DEBUG_MESSAGE) >= 3
    wxString nullTester;
    if (nullTester.IsNull() && (nullTester == wxEmptyString)){ // The "wxEmptyString.IsNull()" is equal to "true"
        wxMessageBox( wxString("A non initialized wxString object is a 'wxEmptyString' object and also a null wxString object."),
                      wxString("Debubg info"),wxOK|wxCENTRE);
    };
#endif

    wxString nextpath = wxEmptyString;
    if (path.IsNull() && (this->parent != NULL)){ // "An 'wxEmptyString' object is a null 'wxString' object."
        nextpath = this->GetPath();
    };

    wxString output = this->ToString(path);
    if (this->childrenDirs.size() > 0) {
        nextpath += path + this->name + wxFILE_SEP_PATH;
        std::list<SysDir*>::iterator it = this->childrenDirs.begin();
        std::list<SysDir*>::iterator itf = this->childrenDirs.end();
        for(; it!=itf; ++it) {
            output << (*it)->TreeToString(nextpath) << " \n";
        };
    }
    return output;
};


Tree::Tree(int maxitem){
    this->itemMax = maxitem;
    this->itemNumb = 0;
};


void Tree::SetFlags(bool properties, bool recur, ITEMNUMB itemMx) {
    FileSysObj::prop = properties;
    FileSysObj::recursive = recur;
    FileSysObj::maxitem = itemMx;
};


bool Tree::Compose(const wxString &rt, bool properties, bool recursive){
    if (rt == wxEmptyString)
        return false;

    wxDir dir(rt);
    if (!dir.IsOpened()) {  // Check if 'rt' is a valid accessible Directory and opens it.
        wxMessageBox(wxString("The selected Root Directory could not be opened!"),
                     wxString("Root Directory Access ERROR"), wxOK | wxCENTRE | wxICON_ERROR);
        return false;
    }
    dir.Close();
    this->Clear();
    this->SetFlags(properties, recursive, this->itemMax);
    this->root = SysDir();
    if (!this->root.SetRoot(this, rt) )
        return false;

    this->itemNumb = 1;
    FileSysObjCounter rootCntr = {0, 0, 0, 0, 0, 0};

    if (recursive) {
        // rootCntr.Sum(rootCntr, this->root.RecursiveTraverse(itemMax));
        rootCntr.Assign(this->root.StartRecursiveTraverse());
    } else {
#if (MY_DEBUG_MESSAGE) >= 1
wxMessageBox(wxString("Start simple TRAVERSE ") ,
             wxString("Debubg info"),wxOK|wxCENTRE);
#endif
        rootCntr = this->root.StartTraverse();
    }

    return true;
};


wxString Tree::Result() {
    wxString result = FileSysObj::recursive ? this->root.TreeToString() : this->root.ToString() ;
    return (result + "\n======================*** FINISHED ***======================");
};


void Tree::Clear() {

};

