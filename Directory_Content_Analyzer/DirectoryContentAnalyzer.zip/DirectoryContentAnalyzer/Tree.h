/***************************************************************
 * Name:      DirectoryContentAnalyserMain.cpp
 * Purpose:   Definition for Tree Structure
 * Author:    Vinicius Calil ()
 * Created:   2019-02-08
 * Copyright: Vinicius Calil ()
 * License:
 * Compiler:  TDM-GCC Suite for Windows
 *                 #) gcc-5.1.0-tdm-1-core
 *                 #) binutils-2.24-1-mingw32-bin
 *                 #) mingwrt-3.20-2-mingw32-dev, mingwrt-3.20-2-mingw32-dll
 *                 #) w32api-3.17-2-mingw32-dev
 *                 #) gcc-5.1.0-tdm-1-c++
 *                 #) make-3.82.90-2-mingw32-cvs-20120902-bin,    libintl-0.17-1-mingw32-dll-8, libiconv-1.13.1-1-mingw32-dll-2
 *                 #) gdb32-7.9-tdm-1
 * GUI and Additional Libraries:  wxWidgets - version 3.1.2
 **************************************************************/



// Help Documentation:
// https://docs.wxwidgets.org/3.1/classwx_file_name.html
// https://docs.wxwidgets.org/3.1/filename_8h.html
// https://docs.wxwidgets.org/3.1/classwx_dir.html
// https://docs.wxwidgets.org/3.1/group__group__funcmacro__file.html
// https://docs.wxwidgets.org/3.1/group__group__class__file.html


#ifndef TREE_H_INCLUDED
#define TREE_H_INCLUDED

#include <iostream>
#include <list>
#include <wx/intl.h>
#include <wx/string.h>
#include <wx/datetime.h>
#include <wx/filename.h>
#include <wx/msgdlg.h>
#include <wx/dir.h>
#include <wx/longlong.h>
#include <ctime>

#ifdef __WXMSW__
/*
    //#include <fileapi.h>
    #include <Windows.h>
    #include <WinBase.h>
*/
#endif // __WXMSW__

#if defined(TREE_CPP)  // Macro that define/implement GLOBAL VARIABLES in Tree.cpp file and declare those GLOBAL VARIABLES in other files.
    #define _extern_var_
#else
    #define _extern_var_ extern
#endif // defined(TREE_CPP)

typedef int_fast64_t ITEMNUMB ;


typedef struct _FileSysObjCounter {
    ITEMNUMB regFile, symLink, dir, others;
    ITEMNUMB erroFile, erroDir;
    void Clear() {regFile = symLink = dir = others = erroFile = erroDir = 0;};
    ITEMNUMB Viewed(){return regFile + symLink + dir + others;};
    ITEMNUMB Errors() {return erroFile + erroDir;};
    void Sum(struct _FileSysObjCounter &op1, // 'op1' could be made "const" but would not allow the use of the function this way 'OP1.Sum( OP1, SecondOP);'
             struct _FileSysObjCounter const &fsc);
    void Assign(struct _FileSysObjCounter const &fsc);
} FileSysObjCounter;

class Tree;


class Tree {
private:
    class FileSysObj { // basic properties of any File System Object (regular file, directory, symboliuc link, device, socket, etc).
    protected:
        wxString name;  // This member must be protected to allow modification only true 'SetSystemObjectTo()' method. It is because a value different from wxEmptyString is an indication that the System Object is valid.
        FileSysObj* parent;
        std::list<ITEMNUMB> pos;  // Item position inside the tree. First sibling ref "0" index.
        wxDateTime dt_modified;
        wxDateTime dt_created;
        wxDateTime dt_accessed;
    public:
        static bool prop;  // Flag that indicates if user requested properties to be read and displayed.
        static bool recursive;  // Flag that indicates that the analyses must also verify subdirectories contents recurssively.
        static ITEMNUMB maxitem;  // Flag that set the maximum number of file system objects to be viewed or analysed.
        static void SetFlags(bool properties, ITEMNUMB itemMx);
        FileSysObj();
        wxString GetName() {return this->name;};
        wxString GetPath(); //{ return (wxPathOnly(this->name));};
        std::list<ITEMNUMB> GetPosition();
    };

    class SysFile;   // Forward declaration.

    class SysDir : public FileSysObj{
    protected:
        std::list<SysDir*> childrenDirs;
        std::list<SysFile*> childrenFiles;
        ITEMNUMB localfiles;  // Total number of regular files entry inside this SysDir object that has been correctly inserted into its 'childrenFiles'.
        ITEMNUMB localsymlink;  // Total number of symbolic link entry inside this SysDir object that has been correctly inserted into its 'childrenFiles'.
        ITEMNUMB localdirectories;    // Total number of (sub)directories entry inside this SysDir object that has been correctly inserted into its 'childenDirs' and 'childrenFiles'.
        ITEMNUMB localothers;    // Total number of other types files (DEVICE, FIFO, SOCKET, Terminal-tty?, PIPE?) entry inside this SysDir object that has been correctly inserted into its 'childrenFiles'.
        ITEMNUMB localerrorsfile;   // Total number of regular and other file types (DEVICE, FIFO, SOCKET, Terminal-tty?, PIPE?) entry inside this SysDir object that could NOT been inserted into its 'childrenFiles'.
        ITEMNUMB localerrorsdir;   // Total number of subdirectories entry inside this SysDir object that could NOT been inserted into its 'childrenDirs'.
        ITEMNUMB subdirfiles; // Total number of regular files entry inside all subdirectories of this SysDir object that has been correctly inserted into its respective 'childrenFiles'.
        ITEMNUMB subdirsymlink;  // Total number of symbolic link entry inside all subdirectories of this SysDir object that has been correctly inserted into its respective 'childrenFiles'.
        ITEMNUMB subdirdirectories;  // Total number of subdirectories entry inside all (first levelsub)directories of this SysDir object that has been correctly inserted into its respective 'childrenDirs'.
        ITEMNUMB subdirothers;    // Total number of other types files (DEVICE, FIFO, SOCKET, Terminal-tty?, PIPE?) entry inside all subdirectories of this SysDir object that has been correctly inserted into its respective 'childrenFiles'.
        ITEMNUMB subdirerrorsfile;   // Total number of regular and other file types (DEVICE, FIFO, SOCKET, Terminal-tty?, PIPE?) entry inside all subdirectories of this SysDir object that could NOT been inserted into its respective 'childrenFiles'.
        ITEMNUMB subdirerrorsdir;   // Total number of subdirectories entry inside all (first levelsub)directories of this SysDir object that could NOT been inserted into its respective 'childrenDirs'.
    public:
        SysDir();
        ~SysDir();
        bool SetSystemObjectTo(const wxString &Fname, const wxString &Fpath); // Set 'name', 'type', dates (modified, accessed, created) and 'len' (if 'name' refers to a file).
        bool SetRoot(Tree* tree, const wxString &Fullname);  // set 'parent' and 'pos'.//ITEMNUMB GetSiblingFileIndex(FileSysObj* child); // A FileSys object may use 'this->parent.GetSiblingIndex(this)' to know its index position inside "this->parent.children" list<FileSys>.
        bool SetFileChild(SysFile* child);
        bool SetDirChild(SysDir* child);
        ITEMNUMB GetFileSiblingIndex(SysFile* child); // A FileSys object may use 'this->parent.GetSiblingIndex(this)' to know its index position inside "this->parent.children" list<FileSys>.
        ITEMNUMB GetDirSiblingIndex(SysDir* child); // A FileSys object may use 'this->parent.GetSiblingIndex(this)' to know its index position inside "this->parent.children" list<FileSys>.    };
        FileSysObjCounter StartTraverse() { return this->Traverse(0, this->name + wxFILE_SEP_PATH); }
        FileSysObjCounter Traverse(ITEMNUMB nitem, const wxString& path); // Fill 'childrenFiles' and 'childrenDirs' creating new 'FileSysObj' to each file or directory inside this 'SysDir' object.
        FileSysObjCounter StartRecursiveTraverse(){ return this->RecursiveTraverse(0, this->name + wxFILE_SEP_PATH); };
        FileSysObjCounter RecursiveTraverse(ITEMNUMB nitem, const wxString& path); // Fill 'childrenFiles' and 'childrenDirs' creating new 'FileSysObj' to each file or directory inside this 'SysDir' object.
        void LoadLocalStatistics(FileSysObjCounter &statistics);
        void LoadSubdirStatistics(FileSysObjCounter &statistics);
        wxString ToString(const wxString &path = wxEmptyString);
        wxString TreeToString(const wxString &path = wxEmptyString);
    };

    class SysFile : public FileSysObj{
        int type;
        wxULongLong len; // If it 'this.name' is an accessible file, '_size' stores the file length (in bytes).
    public:
        enum fs_type{
            regularFile = 1,
            symbolicLink = 2,
            others = 3   // It can be DEVICE, FIFO, DIRECTORY, SOCKET.
        } ;
        SysFile() : type(0), len(0) {}; // Constructor.
        bool SetSystemObjectTo(const wxString &Fname, const wxString &Fpath); // Set 'name', 'type', dates (modified, accessed, created) and 'len' (if 'name' refers to a file).
#ifdef __WXMSW__
/*  Intended to furute use of Microsoft NTFS Alternate Data Stream (ADS)
    private:
        struct AltDataStream {
            wxString adsName;  // name of Alternate DATA Stream (ADS) present in NTFS file system.
            int_fast64_t sz;   // size of ADS
        };
        std::list<AltDataStream> ads_list;
    public:
        SysFile();
        ~SysFile();
*/
#endif // __WXMSW__

        friend class SysDir;
    };

private:
    ITEMNUMB itemMax;   // Maximum number of FileSys objects that a single 'Tree' object can hold.
    ITEMNUMB itemNumb;  // Actual number of items that this tree object holds.
    wxString path; // Absolut path of the root item in respective file system.
    bool properties;

    SysDir root;


public:
    explicit Tree(int maxitem = 1000);
    void Clear();
    bool Compose(const wxString &rt, bool properties, bool recursive);
    FileSysObjCounter cntr;
    ~Tree() {Clear();}
    //void SetFlags(bool properties, ITEMNUMB itemMx);
    void SetFlags(bool properties = false,
                     bool recur = false,
                     ITEMNUMB itemMx = 1024);
    wxString Result();
//    FileSysObjCounter StartTraverse() { return this->root.Traverse(0, this->root.name + wxFILE_SEP_PATH); }
//    FileSysObjCounter StartRecursiveTraverse(){ return this->root.RecursiveTraverse(0, this->root.name + wxFILE_SEP_PATH); };

};


#endif // TREE_H_INCLUDED
