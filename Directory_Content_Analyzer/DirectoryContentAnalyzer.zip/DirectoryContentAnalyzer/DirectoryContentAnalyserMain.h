/***************************************************************
 * Name:      DirectoryContentAnalyserMain.h
 * Purpose:   Defines Application Frame
 * Author:    Vinicius Calil ()
 * Created:   2019-02-07
 * Copyright: Vinicius Calil ()
 * License:
 **************************************************************/

#ifndef DIRECTORYCONTENTANALYSERMAIN_H
#define DIRECTORYCONTENTANALYSERMAIN_H

//(*Headers(DirectoryContentAnalyserFrame)
#include <wx/button.h>
#include <wx/checkbox.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/radiobut.h>
#include <wx/sizer.h>
#include <wx/statusbr.h>
#include <wx/textctrl.h>
//*)

#include "Tree.h"

class DirectoryContentAnalyserFrame: public wxFrame
{
    public:

        DirectoryContentAnalyserFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~DirectoryContentAnalyserFrame();

    private:

        //(*Handlers(DirectoryContentAnalyserFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnClose(wxCloseEvent& event);
        void OnBt_SearchBaseDirClick(wxCommandEvent& event);
        void OnRdBt_CompareDirectoriesSelect(wxCommandEvent& event);
        void OnRdBt_ListContentsSelect(wxCommandEvent& event);
        void OnBt_SearchComparedDirClick(wxCommandEvent& event);
        void OnCkBx_ListAllClick(wxCommandEvent& event);
        void OnTxCt_BaseDirectoryText(wxCommandEvent& event);
        void OnBt_AnalyzeClick(wxCommandEvent& event);
        //*)

        //(*Identifiers(DirectoryContentAnalyserFrame)
        static const long ID_TXCT_BASEDIRECTORY;
        static const long ID_BUTTON1;
        static const long ID_RDBT_LISTCONTENTS;
        static const long ID_RDBT_COMPAREDIRECTORIES;
        static const long ID_TXCT_COMPAREDDIRECTORY;
        static const long ID_BT_SEARCHCOMPAREDDIRECTORY;
        static const long ID_CKBX_SHOWPROPERTIES;
        static const long ID_CKBX_ANALYZESUBDIR;
        static const long ID_CKBX_LISTALL;
        static const long ID_CKBX_LISTEQUALS;
        static const long ID_CKBX_LISTDIFFERENTS;
        static const long ID_CKBX_LISTABSENTS;
        static const long ID_CKBX_LISTBIGGERS;
        static const long ID_BT_ANALYZE;
        static const long ID_BT_EXPORT;
        static const long ID_TXCT_USEROUTPUT;
        static const long ID_PANEL1;
        static const long ID_MENUITEM1;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(DirectoryContentAnalyserFrame)
        wxButton* Bt_Analyze;
        wxButton* Bt_Export;
        wxButton* Bt_SearchBaseDir;
        wxButton* Bt_SearchComparedDir;
        wxCheckBox* CkBx_AnalyzeSubDir;
        wxCheckBox* CkBx_ListAbsents;
        wxCheckBox* CkBx_ListAll;
        wxCheckBox* CkBx_ListBiggers;
        wxCheckBox* CkBx_ListDifferents;
        wxCheckBox* CkBx_ListEquals;
        wxCheckBox* CkBx_ShowProperties;
        wxPanel* Panel1;
        wxRadioButton* RdBt_CompareDirectories;
        wxRadioButton* RdBt_ListContents;
        wxStatusBar* StatusBar1;
        wxTextCtrl* TxCt_BaseDirectory;
        wxTextCtrl* TxCt_ComparedDirectory;
        wxTextCtrl* TxCt_UserOutPut;
        //*)

        DECLARE_EVENT_TABLE()


        wxString BaseDirectoryName;
        wxString ComparedDirectoryName;
        Tree TreeBDir, TreeCDir;

};

#endif // DIRECTORYCONTENTANALYSERMAIN_H
