#include <iostream>
#include <fstream>
#include <cstdlib>
#include <limits>
#include <cstring>
#include <exception>
#include <string>
#include <cctype>

using namespace std;

typedef const int stgsz;   // Used to define string sizes (including NULL characters).
stgsz sz1 = 245;     // This value must be greater or equal to 10;
stgsz sz2 = 8194;
const char ADS_delim = '|';   // Define the delimiter character of the text to be appended in the ADS. No character after this will be read.

int trim_search_n(char *str, stgsz sz_lim, bool trim_mode = false) {
    // This function returns:
    //   *) for trim_mode = false:  (trim leading characters)
    //         the position index of the first (leading) character, that is NOT
    //         a control neither a space character, is returned.
    //   *) for trim_mode = true:  (trim trailing characters)
    //         the position index of the last (trailing) character before the
    //         index value in the 'sz_lim' argument, that is NOT a control neither a space character, is returned.

    if (sz_lim < 2) return -1;  // The array has not enough characters to be trimmed.

    if (trim_mode) {  // Trim trailing spaces.
        // In this mode, the argument of 'sz_lim' is the position index of the first
        // character by which the backward search for graphic chacarters will start.
        // The argument usually is the real size of the char array.  But, it also may be:
        //     *) the length of a string (with NULL terminating character) already present in the char array,
        //     *) the length of a substring, if any string is already present in the char.

        size_t len = strnlen (str, sz_lim);  // Length of the string (if) present in the char array or, if no NULL character is found, the 'sz_lim' value.
        char * aux = str + (len - 1);        // A pointer to the first character by which the backward search will start.
            // NOTE: if len = sz_lim the search will start by the last character (position index 'sz_lim - 1');
            //       otherwise (len < sz_lim), the search will start by the character immediately before
            //       the first NULL character occurrence in the char array.;
        while( (aux >= str) && (!isgraph(*aux))  )  aux--;

        return ( (aux < str)?  -2 : (int)(aux - str) ) ;
              // NOTE: the return value "-2" means "all characters were trimmed".

    } else {  // Trim leading spaces.
            // In this mode, the argument of 'sz_lim' is the size of the 'str' array.

        if (*str == '\0') return -2; // NOTE: the return value "-2" means "all characters were trimmed".

        int charpos= 0;     // Index of the next character that will be checked.
        while( (charpos < sz_lim-1) && (!isgraph(*str))  )  str++, charpos++;
              // NOTE: as the last character of a char array must be the NULL
              //       character so it can be correctly treated as a string, the
              //       last character of the array 'str' (indicated by the index
              //       value 'sz_lim - 1') is not verified.

        return ((charpos == sz_lim-1)?  -2 : charpos);
              // NOTE: the return value "-2" means "all characters were trimmed".
    }

}


int copy_inside(char *inpstr, stgsz ix0, stgsz ix1) {
    // This function moves a substring to the beginning of the "inpstr" array.
    // The 'ix0' is the position index of the first character to be copied to
    // beginning of the 'inpstr' array.
    // The 'ix1' is the position index of the last character to be copied.
    // If the last copied character is NOT the NULL terminating, the string
    // will require additional procedure to insert it.

    if (ix0 <  0 ) return -1;   // Error: the position index in "ix0" must be greater or equal to '0'.
    if (ix1 < ix0) return -2;   // Error: the position index in "ix1" must be greater or equal to "ix0" value.

    int len = ix1 - ix0 +1;

    if (ix0 != 0)  {  //The 'inpstr' has characters that must be "moved".
        char *nxt = inpstr + ix0;   // Use the 'nxt' pointer to point to the next character inside the 'inpstr' array that will be copied.
        char *last = inpstr + ix1;  // Use the 'last' pointer to point to the last character inside the 'inpstr' array that will be copied.
        while (nxt <= last) {
            *inpstr = *nxt;
            inpstr++;
            nxt++;
        }
    }

    return (len);
}


inline void escprog(char c) {
    // This function is used to allow the user to terminate (escape) the application at any moment.
    if(c =='0') { exit(EXIT_SUCCESS); };
};


int get_user_input(const char * msg, char * inpstr, stgsz sz_lim){
    // This function returns the length of the user input, limited
    // to a total number of character defined by 'sz_lim' argument.

    size_t len = 0;
    if (sz_lim < 2) return -1;   // The array has not enough characters to hold any valid information.
    try {
        std::cout << msg << "\n";   // Show a message to the user.
        std::cin.getline(inpstr, sz_lim, '\n');   // Read the answer from the user.
            //--NOTE: When the delimiter character is found, the function
            //        "istream& istream::getline(char* s, streamsize n, char delim );"
            //        does "extract" it (i.e. the stream input pointer position does
            //        pass beyond this character, but it is not copied to the string).
            //        This is a good approach to work if "std::cin" when the delimiter
            //        is "\n", because the system seems to read the "std::cin" buffer
            //        only when the "ENTER" key ('\n') is pressed. But the function
            //        will return only when the delimiter is found. Otherwise the
            //        function will wait for more "user input".

  if (std::cin.fail()) {
    std::cout << "\nError writing to test.txt\n";
    std::cin.clear();
  }


        int ix0 = trim_search_n(inpstr, sz_lim, false);   // Return the position index of the first valid character.
        if (ix0 < 0) return -2;  // There is no valid (isgraph) character in the 'inpstr' array.
            // NOTE: at this point, we know that 'inpstr' array has at least one valid character.

        //## check if user want to exit the program.
        if ( (ix0 <= sz_lim-2) && (!isgraph(inpstr[ix0 + 1])) ) escprog(inpstr[ix0]);

        int ix1 = trim_search_n(inpstr, sz_lim, true);   // Return the position index of the last valid character.
            // NOTE: we do NOT need check if (ix1 >= 0) because we know that there is at least one valid character in 'inpstr' array.

        //## "Move" the valid user input characters to the beginning of the 'inpstr' array.
        len = copy_inside(inpstr, ix0, ix1);
            // NOTE: we do NOT need check if (len > 0) because we know that there is at least one valid character in 'inpstr' array.

        //## Inset NULL terminator.
        if (ix0 > 0) {
            inpstr[len] = '\0';
        } else {   // NOTE: at this point, we know that "ix0 >= 0". Then, this 'else' statement will run only when "ix0 = 0".
            if (ix1 == (sz_lim - 1) ) {
                // NOTE: The last valid character of 'inpstr' is at the last position of
                //       the array. Then, there is no NULL terminating character. This last
                //       character will be overwritten and the string will be truncated.
                //       Such condition may happen if user insert more character than the
                //       size of the array.
                inpstr[ix1] = '\0';
            } else {
                // NOTE: the last valid character is NOT at the last position of the 'inpstr'
                //        array, it is before that position. The position after the last valid
                //        character will be overwritten with the NULL character.
                inpstr[ix1 + 1] = '\0';
            }
        }

        return (len);

    } catch (std::exception &exc) {
        std::cout << "\nERROR:\n" << exc.what() << "\n";
        return -3;
    }

}


int main() {
    char fn[sz1];      // For File Names (including all its path).
    char adsn[sz1];    // For Alternate Data Stream Names.
    const char fstm[sz1] = ":$DATA"; // Keyword used by MS Windows NTFS file system to indicate the complete name of a file and its ADS.
    int lenFn = -1;     // Length of the file name.
    int lenAds = -1;    // Length of the ADS.

    while (1){
        // This is meant to keep the program running until the user exit the program.

    lenFn = -1;   // Reset initial value.
    lenAds = -1;  // Reset initial value.

    //## Ask the user for the name of a file in which the tests (ADS insertion or read) will be made.
    while (lenFn < 1) {
        lenFn = get_user_input(
              "\nEnter the full name (path, name and extension) of the file in which " \
              "ADS will be tested (or enter \'0\' to exit): ",
              fn, sz1);
    }

    //## Ask the user for the name of the ADS that will be used in the tests (ADS insertion or read).
    while (lenAds < 0) {
        std::cout << "\nEnter a name for the ADS that will be tested (or enter \'0\' to exit): ";
        lenAds = get_user_input(
              "\n\t- NOTE: to select the file's main stream (instead of any ADS) just press ENTER key - ",
              adsn, sz1);
        if (lenAds == -2) lenAds = 0;   // When there is NO valid characters in the user input, the file's main stream will be used in the tests, instead of any ADS.
    }

    //## Generate the correct file name plus ADS name and other symbols required to access an ADS.
    if (lenAds > 0) {
        //## Check remaining space  in the "fn" array to concatenate with the ADS name.
        if (sz1 > (lenFn + lenAds + 7) ) {
            strncat(fn,  ":", sz1);  // Includes the introducing symbol for the ADS name.
            strncat(fn, adsn, sz1);  // Includes the ADS name.
            strncat(fn, fstm, sz1);  // Includes the final symbols to allow access to an ADS.
        } else {
            std::cout << "\n\nERROR: there is no enough space in the file name buffer." \
                      << " Please choose a smaller name.";
            exit(EXIT_FAILURE);
        }
        std::cout << "\n\nThe selected stream is an Alternate Data Stream:";
    } else {
        std::cout << "\n\nThe selected stream is the file's main stream:";
    }
    std::cout << "\n\t" << fn;


    //## Ask the user for the type of test that must be done.
    strncpy(adsn, "0", 2);
    lenAds = -1;
    while ( (lenAds < 1) ||
           ((adsn[0]!='I')&&(adsn[0]!='i')&&(adsn[0]!='R')&&(adsn[0]!='r')) ) {
        std::cout << "\n\nSelect the test operation to be applied to the selected stream:";
        lenAds = get_user_input(
              "\n\tpress I to insert a new or append an existing stream;" \
              "\n\tpress R to read the stream;\n\tpress 0 to exit.\n",
              adsn, sz1);
    }

    //## Insert a new user input into the selected stream.
    if ((adsn[0]=='I')||(adsn[0]=='i')) {
        std::ofstream f(fn, ios::out | ios::binary | ios::app );
        char mssg[sz2];      // Buffer to receive the user input (the text) that will be appended to the selected stream.
        streamsize inplen;   // Length of the string inserted into "mssg" from the user input.
        if (!f.is_open()) {
            std::cout << "\n" << fn << "could not be open!";
            exit (EXIT_FAILURE);
        };
        std::cout << "\nEnter the text to append to the selected stream (insert character \'" \
             << ADS_delim << "\', vertical bar, to finish the input)." \
             << "\n---------------------------------------------------------------------------------------------\n";
        std::cin.get(mssg, sz2, ADS_delim);
            //--NOTE: Even when the delimiter character is found, the function
            //        "istream& istream::get(char* s, streamsize n, char delim);"
            //        does not "extract" it (i.e. the stream input pointer position does
            //        not pass beyond this character and it is not copied to the string).
            //        This is a good approach to work if "std::cin" when the delimiter
            //        is NOT "\n". Although, because the system seems to read the "std::cin"
            //        buffer only when the "ENTER" key ('\n') is pressed, if more characters
            //        are present after the delimiter, the istream buffer will keep those
            //        characters. in the user input.
            //        In any case, using this function with "std::cin" requires a call to
            //        "std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');".
            //        This will clean all the "std::cin" buffer.
            //        Without calling "ignore()" , the next calls to "get()" or "getline()"
            //        functions will use the remaining characters (from the first user
            //        input), starting by the delimiter found in the previous call of "get()".
            //        It may cause undesired characters been inserted in the string "s" or
            //        even no character been copied to string "s" (when "get()" is called
            //        successively) .

        inplen = std::cin.gcount();  // Return the index of the input cursor position of the delimiter character. This is the length of the string copied by the "get()" function.
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Get rid of any other character in "std::cin" buffer that does NOT fit in the 'sz_lim' limit of
            //  NOTE: When the delimiter character is found, the function
            //        "istream& istream::ignore(streamsize n = 1, int delim = EOF);"
            //        does "extract" it (i.e. the stream input pointer position does
            //        pass beyond this character).
            //        ??? If the delimiter is "EOF" the a call to this function from
            //            "std::cin" will block the program until (somehow) the EOF
            //            character be entered by the user (by the keyboard). ???
            //        Because the system seems to read the "std::cin" buffer only when
            //        the "ENTER" key ('\n') is pressed, using '\n' as the delimiter
            //        for "std::cin" will extract all remaining characters.

        f.write(mssg, inplen);
    };

    //## Insert a new user input into the selected stream.
    if ((adsn[0]=='R')||(adsn[0]=='r')) {
        std::ifstream f(fn, ios::in | ios::binary);
        char mssg[sz2];
        if (!f.is_open()) {
            std::cout << "\nThe selected stream could not be opened.";
            exit (EXIT_FAILURE);
        };
        std::cout << "\nThe text from the selected stream is:" \
             << "\n-------------------------------------------------------------------------------------\n";
        f.read(mssg, sz2);
        std::cout << mssg;
    };

    cout << "\n\n===================================== // // // =====================================\n";

    // system("PAUSE");
    }

    return 0;
};



